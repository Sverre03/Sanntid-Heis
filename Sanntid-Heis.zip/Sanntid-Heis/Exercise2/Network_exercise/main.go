package main

import (
	"fmt"
	"net"
	"time"
)

// We define some custom struct to send over the network.
// Note that all members we want to transmit must be public. Any private members
//
//	will be received as zero-values.
type HelloMsg struct {
	Message string
	Iter    int
}

const ServerIP string = "10.100.23.204"
const Port int = 20011

func listenToServerUDP(address string) {
	addr, err := net.ResolveUDPAddr("udp", address)

	if err != nil {
		fmt.Println("Connection failed listen")
	}

	conn, err := net.ListenUDP("udp", addr)

	if err != nil {
		fmt.Println("Connection failed listen")
	}

	for {
		buffer := make([]byte, 1024)
		n_bytes, _, err := conn.ReadFromUDP(buffer)

		if err != nil {
			fmt.Println("Connection failed listen")
		}
		fmt.Println(string(buffer[0:n_bytes]))
	}
}

func writeToServerUDP(address string) {
	addr, err := net.ResolveUDPAddr("udp", address)

	if err != nil {
		fmt.Println("Connection failed write")
	}

	conn, err := net.DialUDP("udp", nil, addr)

	if err != nil {
		fmt.Println("Connection failed write")
	}

	for {

		_, err = conn.Write([]byte("Group54"))

		if err != nil {
			fmt.Println("Connection failed write")
		}
		time.Sleep(500 * time.Millisecond)
	}
}

func TCPClient() {
	var address string = fmt.Sprintf("%s:%d", ServerIP, 34933)
	addr, err := net.ResolveTCPAddr("tcp", address)

	if err != nil {
		fmt.Println("ResolveTCPAddr failed")
	}

	conn, err := net.DialTCP("tcp", nil, addr)

	if err != nil {
		fmt.Println("DialTCP failed")
	}

	defer conn.Close()

	buffer := make([]byte, 1024)

	_, err = conn.Write([]byte("Hello TCP"))

	if err != nil {
		fmt.Println("Connection failed TCP write 3")
	}

	// data, err := bufio.NewReader(conn).ReadString('\n')
	data, err := conn.Read(buffer)
	fmt.Println(string(buffer[0:data]))
}

func requestConnectionFromServer() {
	var address string = fmt.Sprintf("%s:%d", ServerIP, 34933)
	addr, err := net.ResolveTCPAddr("tcp", address)

	if err != nil {
		fmt.Println("ResolveTCPAddr failed")
	}

	conn, err := net.DialTCP("tcp", nil, addr)

	if err != nil {
		fmt.Println("DialTCP failed")
	}

	defer conn.Close()

	_, err = conn.Write([]byte("Connect to: 10.100.23.21:20011\x00"))

	if err != nil {
		fmt.Println("Connection failed TCP write 3")
	}
}

func TCPServer() {
	localAddr, err := net.ResolveTCPAddr("tcp", ":20011")

	if err != nil {
		fmt.Println("ADR creation failed")
	}

	listener, err := net.ListenTCP("tcp", localAddr)

	if err != nil {
		fmt.Println("Listener creation failed")
	}

	defer listener.Close()
	requestConnectionFromServer()

	conn, err := listener.Accept()

	if err != nil {
		fmt.Println("connection creation failed")
	}

	defer conn.Close()

	_, err = conn.Write([]byte("Test"))

	if err != nil {
		fmt.Println("Write failed")
	}
	buffer := make([]byte, 1024)

	_, err = conn.Read(buffer)

	if err != nil {
		fmt.Println("read failed")
	}

	fmt.Println("We received something! ", string(buffer[:]))

}

func main() {
	TCPServer()
	// go listenToServerUDP(fmt.Sprintf(":%d", Port))
	// go writeToServerUDP(fmt.Sprintf("%s:%d", ServerIP, Port))

	// time.Sleep(100 * time.Second)
}
